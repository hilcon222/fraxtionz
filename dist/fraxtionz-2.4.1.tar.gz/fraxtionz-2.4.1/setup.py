import setuptools

setuptools.setup(py_modules=["fraxtionz"],
                 install_requires=[],
                 build_requires=['sphinx'])
